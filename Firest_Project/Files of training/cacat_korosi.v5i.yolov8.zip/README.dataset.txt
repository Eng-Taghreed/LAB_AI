# cacat_korosi > 2023-10-24 2:05pm
https://universe.roboflow.com/sekar/cacat_korosi-lvtlf

Provided by a Roboflow user
License: CC BY 4.0

