# Corrosion > 2023-10-13 9:09am
https://universe.roboflow.com/nugroho-indra-kurniawan/corrosion-5xk7b

Provided by a Roboflow user
License: CC BY 4.0

